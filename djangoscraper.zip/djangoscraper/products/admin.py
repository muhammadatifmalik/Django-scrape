from django.contrib import admin
from .models import Brand, Product

admin.site.register(Brand)
admin.site.register(Product)
